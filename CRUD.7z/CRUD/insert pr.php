<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Insert product</title>
</head>
<body>
	<h3>Insert product here</h3>
	<form method="POST">
		
	Pro_id:<input type="number" name="id"></br><br>
	Pro_name:<input type="text" name="name"></br>
		Quantity:<input type="text" name="quantity"></br>
		Quality:<input type="text" name="quality"></br>
		<input type="submit" name="save"></br>
	</form>

<?php 
include 'connect.php';
if (isset($_POST['save'])) {
	$g=$_POST['id'];
	$a=$_POST['name'];
	$b=$_POST['quantity'];
	$c=$_POST['quality'];


	$ins=mysqli_query($conn,"insert into product values ('$g','$a','$b','$c')");

	if ($ins) {
		header("location:display pr.php");
	}
	else{
		echo "try again";
	}
}





 ?>

</body>
</html>