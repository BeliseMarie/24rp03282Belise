<?php 

include 'connect.php';
$f=$_GET['a'];
$del=mysqli_query($conn,"DELETE FROM payment WHERE pay_id='$f'");
if ($del) {
	header("location:display pay.php");
}
else{
	echo "not deleted";
}

 ?>