<?php 

include 'connect.php';
$z=$_GET['b'];
$x=$_GET['c'];
$n=$_GET['d'];
$m=$_GET['h'];



 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Insert Customer</title>
</head>
<body>
	<h3>Insert Customer here</h3>
	<form method="POST">
		
	    Cus_id:<input type="number" name="id" value="<?php echo $z; ?>"></br><br>
	    Cus_name:<input type="text" name="name" value="<?php echo $x ?>"></br>
		Gender:<input type="text" name="gend" value="<?php echo $n ?>"></br>
		Phone:<input type="text" name="qu" value="<?php echo $m ?>"></br>
		
		<input type="submit" name="save"></br>
	</form>


 <?php 

if (isset($_POST['save'])) {
	$v=$_POST['id'];
	$a=$_POST['name'];
	$b=$_POST['gend'];
	$k=$_POST['qu'];
	
	$up=mysqli_query($conn,"UPDATE customers SET cus_name='$a',gender='$b',phone_number='$k' WHERE cus_id='$v'");

	if ($up) {
		
		header("location:customer display.php");
	}
	else{
		echo "Not updated";
	}

}


  ?>
</body>
</html>
