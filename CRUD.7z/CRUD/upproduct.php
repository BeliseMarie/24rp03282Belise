<?php 
include 'connect.php';
$z=$_GET['b'];
$x=$_GET['c'];
$n=$_GET['d'];
$m=$_GET['e'];

 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Insert product</title>
</head>
<body>
	<h3>Insert product here</h3>
	<form method="POST">
		
	    Pro_id:<input type="number" name="id" value="<?php echo $z; ?>"></br><br>
	    Pro_name:<input type="text" name="name" value="<?php echo $x ?>"></br>
		Quantity:<input type="text" name="quantity" value="<?php echo $n ?>"></br>
		Quality:<input type="text" name="quality" value="<?php echo $m ?>"></br>
		<input type="submit" name="save"></br>
	</form>

 <?php 

if (isset($_POST['save'])) {
	$v=$_POST['id'];
	$a=$_POST['name'];
	$b=$_POST['quantity'];
	$c=$_POST['quality'];
	$up=mysqli_query($conn,"UPDATE product SET product_name='$a',quantity='$b',quality='$c' WHERE product_id='$v'");

	if ($up) {
		
		header("location:display pr.php");
	}
	else{
		echo "Not updated";
	}

}

  ?>