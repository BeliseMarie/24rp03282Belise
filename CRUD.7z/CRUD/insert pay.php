

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Insert Payment</title>
</head>
<body>
	<h3>Insert Payment here</h3>
	<form method="POST">
		
	Pro_id:<input type="number" name="id"></br><br>
	Pay_Date:<input type="date" name="name"></br>
		Pay_Amount:<input type="text" name="quantity"></br>
		
		<input type="submit" name="save"></br>
	</form>
<?php 
include 'connect.php';
if (isset($_POST['save'])) {
	$g=$_POST['id'];
	$a=$_POST['name'];
	$b=$_POST['quantity'];
	


	$ins=mysqli_query($conn,"insert into payment values ('$g','$a','$b')");

	if ($ins) {
		header("location:display pay.php");
	}
	else{
		echo "try again";
	}
}

 ?>

 </body>
</html>