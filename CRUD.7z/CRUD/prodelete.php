 <?php 

include 'connect.php';
$f=$_GET['a'];
$del=mysqli_query($conn,"DELETE FROM product WHERE product_id='$f'");
if ($del) {
	header("location:display pr.php");
}
else{
	echo "not deleted";
}

 ?>