=

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>MANAGEMENT INFORMATION</title>
	<style type="text/css">
		*{
			margin: 0;
			padding: 0;
		}
		.hd{
			background: gray;
			height: 6rem;
			text-align: center;
			color: white;
			font-family: sans-serif;
			margin-left: 0.5rem;
			margin-right: 0.5rem;

		}
		nav a:hover{
			
			color: black;
		}
		nav{
			margin-top: 2rem;
		}
		nav a{
			color: white;
			text-decoration: none;
			margin: 0 50px;
			font-size: 13px;


		}

ul{
	list-style: none;
}
		
		.foot{
			font-family: sans-serif;
			bottom: 0;
			position: absolute;
			text-align: center;
			color: white;
			background: black;
			width: 98.8%;
			height: 3rem;
			margin-left: 0.5rem;
			font-size: 13px;

		}
		.main{
			margin-top: 3rem;
			margin-left: 1rem;
			font-size: 15px;
			font-family: sans-serif;

		}
		ul{
			font-size: 14px;
			font-family: sans-serif;
		}
		li{
			font-size: 12px;
			font-family: sans-serif;
		

		}
		@media (max-width:600px){
			.hd{
				text-align: center;
				background: darkblue;
				justify-content: center;
				color: white;

			}
			nav a{
				text-align: center;
				color: white;
				
			}
			.main{
				color: red;
			}
		}
	
	</style>
</head>
<body>
<div class="hd">
	<h2 style="font-size: 2rem;">SHOP MANAGEMENT SYSTEM</h2>
	<nav>
		<a href="index.php">Home</a>
		<a href="display pr.php">Products</a>
		<a href="display pay.php">Payments</a>
		<a href="">Customers</a>

	</nav>

</div>
<div style="padding-top: 1rem;">
	<center>
		<p>PRODUCT INFORMATION</p><br>
	<table border="1" style="border-collapse: collapse;width: 80%;">
		<tr>
			<th>product_id</th>
			<th>product_name</th>
			<th>quantity</th>
			<th>quality</th>
			<th>Delete</th>
			<th>Update</th>
		</tr>
<?php 
include 'connect.php';


$ql=mysqli_query($conn,"SELECT * FROM product");
while ($bet=mysqli_fetch_array($ql)) {

echo"<tr>";

echo"<td>" .$bet[0]. "</td>";
echo"<td>" .$bet[1]. "</td>";
echo"<td>" .$bet[2]. "</td>";
echo"<td>" .$bet[3]. "</td>";

echo"<td><a href='prodelete.php?a=".$bet[0]."'>Delete</a></td>";
echo"<td><a href='upproduct.php?b=".$bet[0]."&c=".$bet[1]."&d=".$bet[2]."&e=".$bet[3]."'>Edit</a></td>";

echo "</tr>";
}


 ?>
</table>
<br>
<a href="insert pr.php">Add Product</a>
</center>
</div>
<div class=" foot">
	<p style="margin-top: 1rem">&copy;2025 Hirwa shop All rights reserved.</p>
</div>


</body>
</html>