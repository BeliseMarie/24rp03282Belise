<?php 
include 'connect.php';
$z=$_GET['b'];
$x=$_GET['c'];
$n=$_GET['d'];


 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Insert product</title>
</head>
<body>
	<h3>Insert product here</h3>
	<form method="POST">
		
	    Pay_id:<input type="number" name="id" value="<?php echo $z; ?>"></br><br>
	    Pay_Date:<input type="date" name="name" value="<?php echo $x ?>"></br>
		Pay_Amount:<input type="text" name="quantity" value="<?php echo $n ?>"></br>
		
		<input type="submit" name="save"></br>
	</form>





 <?php 
if (isset($_POST['save'])) {
	$v=$_POST['id'];
	$a=$_POST['name'];
	$b=$_POST['quantity'];
	
	$up=mysqli_query($conn,"UPDATE payment SET pay_date='$a',pay_amount='$b' WHERE pay_id='$v'");

	if ($up) {
		
		header("location:display pay.php");
	}
	else{
		echo "Not updated";
	}

}


  ?>
</body>
</html>