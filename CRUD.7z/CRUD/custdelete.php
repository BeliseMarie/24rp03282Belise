<?php 

include 'connect.php';
$f=$_GET['a'];
$del=mysqli_query($conn,"DELETE FROM customers WHERE cus_id='$f'");
if ($del) {
	header("location: customer display.php");
}
else{
	echo "not deleted";
}
 ?>