


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Insert Customer</title>
</head>
<body>
	<h3>Insert Customer here</h3>
	<form method="POST">
		

	Cus_Name:<input type="text" name="cn"></br><br>
	Gender:<input type="text" name="gn"></br><br>
	Phone:<input type="number" name="phon"></br>

		
	<input type="submit" name="save"></br>
	</form>

<?php 
include 'connect.php';
if (isset($_POST['save'])) {
	$a=$_POST['cn'];
	$b=$_POST['gn'];
	$d=$_POST['phon'];
	
	


	$ins=mysqli_query($conn,"insert into customers values (NULL,'$a','$b','$d')");

	if ($ins) {
		header("location:customer display.php");
	}
	else{
		echo "try again";
	}
}

 ?>
</body>
</html>
