<?php

 require_once 'connect.php';

 if (isset($_POST['Create'])) {

    $id=$_POST['User_Id'];
 	$user=$_POST['User_name'];
 	$pin=$_POST['Password'];



 	$insert=mysqli_query($conn,"INSERT INTO users VALUES('$id','$user','$pin')");

 	if ($insert) {
 		echo "user account created.";
 		header('location:index.php');
 	}else
 	{

 		echo "Account not created.";
 	}
 	


 }

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sigh Up here</title>
</head>
<body>
	<h3>SIGN UP HERE</h3>
	<form method="POST">
	 UserId:<input type="text" name="User_Id"></br><br> 
	Username:<input type="text" name="User_name"></br><br>
	Password:<input type="text" name="Password"></br>
		<input type="submit" name="Create"></br>
	</form>


</body>
</html>