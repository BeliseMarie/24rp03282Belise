<?php
session_start();

require_once 'connect.php';
if (isset($_POST['LOGIN'])) {
	

	$name=$_POST['User_name'];
	$password=$_POST['Password'];

	$login="SELECT Password && User_name FROM users WHERE User_name='$name'";

	$result=$conn->query($login);
	if ($result->num_rows> 0) {

		header('location:home.php');
	}else{
		header('location:signup.php');
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login here</title>
	<style type="text/css">
		*{
			padding: 0;
			margin: 0;

		}
		body{

			background: gray;
			padding-top: 5rem;
			text-align: center;
			color: white;
		}
		form{
			text-align: center;
			text-decoration: none;
			border-radius: 10px;
			width: 39cm;
			height: 25cm;
			color: white;



		}
		form input{

			border-radius: 10px;
			height: 0.70cm;
				}

				.button{
					display: inline;



				}

		

	</style>
</head>
<body>
	<h3 >LOGIN HERE</h3>
	<form method="POST">
		
	Username:<input type="text" name="User_name"></br><br>
		Password:<input type="text" name="Password"></br>
	<div class="button">	<input type="submit" name="LOGIN" value="Login"></br>
		<input type="submit" name="SIGN UP" value="Signup"></br></div>
	</form>


</body>
</html>